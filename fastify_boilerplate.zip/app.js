const fastify = require('./fastify-config');
const routes = require('./src/routes');

fastify.register(routes);

const options = {};
Object.defineProperty(options, 'port', { value: process.env.PORT, writable: true, enumerable: true, configurable: true });
Object.defineProperty(options, 'host', { value: process.env.HOST, writable: true, enumerable: true, configurable: true });

fastify.listen(options, async (err) => {
  if (err) {
    fastify.log.error(err);
    process.exit(1);
  }
  fastify.log.info(`Server is listening on port ${fastify.server.address().port}`);
});