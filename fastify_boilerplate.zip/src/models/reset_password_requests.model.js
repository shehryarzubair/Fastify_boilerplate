const { DataTypes, Model } = require("sequelize");
const sequelize = require("./database.config");
const { Users } = require("./users.model");

class ResetPasswordRequests extends Model {}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Users,
      key: "id",
    },
  },
  uuid: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
};

ResetPasswordRequests.init(json_schema, {
  sequelize,
  paranoid: true,
  timestamps: true,
  underscored: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
  deletedAt: "deleted_at",
});
ResetPasswordRequests.belongsTo(Users, { foreignKey: "user_id" });

exports.ResetPasswordRequests = ResetPasswordRequests;
