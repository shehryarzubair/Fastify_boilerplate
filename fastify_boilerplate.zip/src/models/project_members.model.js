const { DataTypes, Model } = require("sequelize");
const sequelize = require("./database.config");
const { Projects } = require("./projects.model");
const { Users } = require("./users.model");

class ProjectMembers extends Model {}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  project_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Projects,
      key: "id",
    },
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Users,
      key: "id",
    },
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
};

ProjectMembers.init(json_schema, {
  sequelize,
  paranoid: true,
  timestamps: true,
  underscored: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
  deletedAt: "deleted_at",
});

ProjectMembers.belongsTo(Projects, { foreignKey: "project_id" });
ProjectMembers.belongsTo(Users, { foreignKey: "user_id" });

exports.ProjectMembers = ProjectMembers;
