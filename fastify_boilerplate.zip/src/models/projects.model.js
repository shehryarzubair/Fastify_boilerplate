const { DataTypes, Model } = require("sequelize");
const sequelize = require("./database.config");
const { Status } = require("./status.model");
const { Companies } = require("./companies.model");

class Projects extends Model {}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  company_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Companies,
      key: "id",
    },
  },
  status_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Status,
      key: "id",
    },
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
};

Projects.init(json_schema, {
  sequelize,
  paranoid: true,
  timestamps: true,
  underscored: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
  deletedAt: "deleted_at",
});

Projects.belongsTo(Companies, { foreignKey: "company_id" });
Projects.belongsTo(Status, { foreignKey: "status_id" });

exports.Projects = Projects;
