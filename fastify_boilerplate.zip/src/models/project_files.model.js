const { DataTypes, Model } = require("sequelize");
const sequelize = require("./database.config");
const { Projects } = require("./projects.model");

class ProjectFiles extends Model {}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  project_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Projects,
      key: "id",
    },
  },
  file: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
};

ProjectFiles.init(json_schema, {
  sequelize,
  paranoid: true,
  timestamps: true,
  underscored: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
  deletedAt: "deleted_at",
});

ProjectFiles.belongsTo(Projects, { foreignKey: "project_id" });

exports.ProjectFiles = ProjectFiles;
