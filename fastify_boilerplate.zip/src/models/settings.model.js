const { DataTypes, Model } = require('sequelize');
const sequelize = require('./database.config');
const HelperFunctions = require('../helper/index');
const { default: slugify } = require('slugify');

class Settings extends Model {
}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  key: {
    type: DataTypes.STRING,
    allowNull: false
  },
  value: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  allow_edit: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  },
  data_type: {
    type: DataTypes.ENUM('integer', 'string', 'boolean', 'float', 'json')
  },
  default_value: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false
  },
};


Settings.init(json_schema, { sequelize, paranoid: false, timestamps: true, underscored: true, createdAt: 'created_at', updatedAt: 'updated_at' });

Settings.beforeCreate((model) => {
  model.key = slugify(model.key, { lower: true, strict: true, replacement: "_" }).toUpperCase();
  model.description = model.description ? HelperFunctions.toSentenceCase(model.description) : null;
});

exports.Settings = Settings;
