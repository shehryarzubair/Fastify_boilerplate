const { DataTypes, Model } = require('sequelize');
const sequelize = require('./database.config');
const { default: slugify } = require('slugify');
const HelperFunctions = require('../helper/index');

class Permissions extends Model {
}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  slug: {
    type: DataTypes.STRING,
    allowNull: true
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  },
};

Permissions.init(json_schema, { sequelize, paranoid: false, timestamps: true, underscored: true, createdAt: 'created_at', updatedAt: 'updated_at' });

Permissions.beforeCreate((permission) => {
  const slug = slugify(permission.name, { lower: false, strict: true, replacement: "_" }).toUpperCase();
  permission.name = HelperFunctions.toSentenceCase(permission.name.toString().toLowerCase());
  permission.slug = slug;
});

Permissions.beforeBulkCreate((permissions) => {
  for (let index = 0; index < permissions.length; index++) {
    const permission = permissions[index];
    const slug = slugify(permission.name, { lower: false, strict: true, replacement: "_" }).toUpperCase();
    permission.name = HelperFunctions.toSentenceCase(permission.name.toString().toLowerCase());
    permission.slug = slug;
  }
});

exports.Permissions = Permissions;
