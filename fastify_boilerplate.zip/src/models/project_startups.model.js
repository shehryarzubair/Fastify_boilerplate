const { DataTypes, Model } = require("sequelize");
const sequelize = require("./database.config");

class ProjectStartups extends Model {}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  category: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
};

ProjectStartups.init(json_schema, {
  sequelize,
  paranoid: false,
  timestamps: true,
  underscored: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
});

exports.ProjectStartups = ProjectStartups;
