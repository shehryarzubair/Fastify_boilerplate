const { DataTypes, Model } = require("sequelize");
const sequelize = require("./database.config");
const { Users } = require("./users.model");
const { Companies } = require("./companies.model");

class Credits extends Model {}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Users,
      key: "id",
    },
  },
  company_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Companies,
      key: "id",
    },
  },
  credits: {
    type: DataTypes.INTEGER,
    allowNull: true,
    defaultValue: 0,
  },
  transaction_type: DataTypes.ENUM("addition", "deduction"),
};

Credits.init(json_schema, {
  sequelize,
  paranoid: true,
  timestamps: true,
  underscored: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
  deletedAt: "deleted_at",
});

Credits.belongsTo(Users, { foreignKey: "user_id" });
Credits.belongsTo(Companies, { foreignKey: "company_id" });

exports.Credits = Credits;
