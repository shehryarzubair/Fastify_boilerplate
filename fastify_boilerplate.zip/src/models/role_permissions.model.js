const { DataTypes, Model } = require("sequelize");
const sequelize = require("./database.config");
const { Roles } = require("./roles.model");
const { Permissions } = require("./permissions.model");

class RolePermissions extends Model {}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  role_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Roles,
      key: "id",
    },
  },
  permission_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Permissions,
      key: "id",
    },
  },
};

RolePermissions.init(json_schema, {
  sequelize,
  paranoid: false,
  timestamps: true,
  underscored: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
});

RolePermissions.belongsTo(Roles, { foreignKey: "role_id" });
RolePermissions.belongsTo(Permissions, { foreignKey: "permission_id" });

Roles.belongsToMany(Permissions, { through: RolePermissions });
Permissions.belongsToMany(Roles, { through: RolePermissions });

exports.RolePermissions = RolePermissions;
