const { DataTypes, Model } = require("sequelize");
const sequelize = require("./database.config");
const { Users } = require("./users.model");
const { ProjectStartups } = require("./project_startups.model");

class StartupScores extends Model {}

const json_schema = {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  startup_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: ProjectStartups,
      key: "id",
    },
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Users,
      key: "id",
    },
  },
  score: {
    type: DataTypes.INTEGER,
    allowNull: true,
    defaultValue: 0,
  },
  is_active: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
};

StartupScores.init(json_schema, {
  sequelize,
  paranoid: true,
  timestamps: true,
  underscored: true,
  createdAt: "created_at",
  updatedAt: "updated_at",
  deletedAt: "deleted_at",
});

StartupScores.belongsTo(ProjectStartups, { foreignKey: "startup_id" });
StartupScores.belongsTo(Users, { foreignKey: "user_id" });

exports.StartupScores = StartupScores;
