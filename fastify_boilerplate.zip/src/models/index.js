const { Users } = require("./users.model");
const { Roles } = require("./roles.model");
const { Permissions } = require("./permissions.model");
const { RolePermissions } = require("./role_permissions.model");
const { Status } = require("./status.model");
const { Companies } = require("./companies.model");
const { Projects } = require("./projects.model");
const { ProjectFiles } = require("./project_files.model");
const { Credits } = require("./credits.model");
const { ProjectMembers } = require("./project_members.model");
const { FailedLoginAttempt } = require("./failed_login_attempts.model");
const { ResetPasswordRequests } = require("./reset_password_requests.model");
const { Settings } = require("./settings.model");
const { ProjectStartups } = require("./project_startups.model");
const { StartupScores } = require("./startup_scores.model");
const { StartupComments } = require("./startup_comments.model");

const models = {
  Users,
  Roles,
  Permissions,
  RolePermissions,
  Status,
  Companies,
  Projects,
  ProjectFiles,
  Credits,
  ProjectMembers,
  ResetPasswordRequests,
  FailedLoginAttempt,
  Settings,
  ProjectStartups,
  StartupScores,
  StartupComments
};
exports.models = models;
