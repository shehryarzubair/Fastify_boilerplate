const fastify = require("../../fastify-config");
const { models } = require("../models/index");
const HelperFunctions = require("../helper");

class AuthenticationMiddleware {
  async handle(request, reply) {
    const { authorization } = request.headers;

    if (!authorization) {
      return HelperFunctions.responseWrapper(
        request,
        reply,
        401,
        "Missing authorization header."
      );
    }

    const token = authorization.replace("Bearer ", "");

    try {
      const decoded = await fastify.jwt.verify(token);
      const verifyUser = await models.Users.findByPk(decoded.user.id);
      if (!verifyUser) {
        return HelperFunctions.responseWrapper(
          request,
          reply,
          401,
          "Invalid token."
        );
      }
      request.user = decoded.user;
    } catch (error) {
      console.log("error-authMiddleware", error);
      return HelperFunctions.responseWrapper(
        request,
        reply,
        401,
        "Invalid token.."
      );
    }
  }
}

module.exports = AuthenticationMiddleware;
