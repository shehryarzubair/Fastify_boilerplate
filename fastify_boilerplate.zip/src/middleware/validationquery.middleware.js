
const HelperFunctions = require('../helper');


class ValidationQueryMiddleware {

    constructor(resourceSchema) {
        this.resourceSchema = resourceSchema;
    }

    async handle(request, reply) {
        try {
            await this.resourceSchema.validate(request.query, { abortEarly: false });
        }
        catch (error) {
            return HelperFunctions.responseWrapper(request, reply, 400, error.errors[0]);
        }
    }
}

exports.ValidationQueryMiddleware = ValidationQueryMiddleware;