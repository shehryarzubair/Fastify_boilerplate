const constants = require("../constants");
const { models } = require("../models/index");
const HelperFunctions = require("../helper");

class PermissionMiddleware {
  constructor(permission) {
    this.permission = permission;
  }

  async handle(request, reply) {
    try {
      const userRole = request.user.role_id;

      if (userRole) {
        const role = await models.Roles.findByPk(userRole);
        if (role && Object.keys(role).length > 0 && role.is_active) {
          const verifiedpermission = await models.Permissions.findOne({
            where: { slug: this.permission },
          });
          if (verifiedpermission) {
            const hasPermission = await models.RolePermissions.findOne({
              where: { role_id: role.id, permission_id: verifiedpermission.id },
            });
            if (hasPermission && Object.keys(hasPermission).length > 0) {
              //
            } else {
              return HelperFunctions.responseWrapper(
                request,
                reply,
                401,
                "Operation not allowed!!!"
              );
            }
          } else {
            return HelperFunctions.responseWrapper(
              request,
              reply,
              401,
              "Operation not allowed!!!"
            );
          }
        } else {
          return HelperFunctions.responseWrapper(
            request,
            reply,
            401,
            "Operation not allowed!!"
          );
        }
      } else {
        return HelperFunctions.responseWrapper(
          request,
          reply,
          401,
          "Operation not allowed!"
        );
      }
    } catch (error) {
      console.log("error-PermissionMiddleware", error);
      return HelperFunctions.responseWrapper(
        request,
        reply,
        401,
        "Operation not allowed!"
      );
    }
  }
}

exports.PermissionMiddleware = PermissionMiddleware;
