const HelperFunctions = require("../helper");

class ValidationMiddleware {
  constructor(resourceSchema) {
    this.resourceSchema = resourceSchema;
  }

  async handle(request, reply) {
    try {
      await this.resourceSchema.validate(request.body, { abortEarly: false });
    } catch (error) {
      return HelperFunctions.responseWrapper(request, reply, 400, error.errors);
    }
  }
}

module.exports = ValidationMiddleware;
