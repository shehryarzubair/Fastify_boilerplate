const HelperFunctions = require("../helper");

class PathVariableMiddleware {
    async handle(request, reply) {
        try {
            const { id } = request.params;
            const valid = HelperFunctions.validatePathVariable(id);
            if (!valid) {
                return HelperFunctions.responseWrapper(request, reply, 400, 'Invalid ID provided.');
            }
        } catch (error) {
            console.log('error-PathVariableMiddleware', error);
            return HelperFunctions.responseWrapper(request, reply, 500, 'Something went wrong');
        }
    }
}
module.exports = PathVariableMiddleware;
