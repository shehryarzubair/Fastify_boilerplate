const constants = require("../constants/index");
const UserSchema = require('../schemas/user.schema');
const UserController = require("../controllers/users.controller");
const AuthenticationMiddleware = require("../middleware/authentication.middleware");
const PathVariableMiddleware = require("../middleware/pathVariable.middleware");

const superAdmin = constants.SUPER_ADMIN;
const viewer = constants.VIEWER;

function routes(fastify, options, done) {

    const controller = new UserController();
    const pathVariableMiddleware = new PathVariableMiddleware();
    const authenticationMiddleware = new AuthenticationMiddleware();

    fastify.get('/users', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_USERS)] }, async (request, reply) => {
        await controller.getAllUserList(request, reply);
    });
    fastify.get('/user/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_USERS), pathVariableMiddleware.handle] }, async (request, reply) => {
        await controller.getUserById(request, reply);
    });
    fastify.post('/add-user', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.CREATE_USER), ValidationMiddleware(UserSchema.addUserSchema)] }, async (request, reply) => {
        await controller.addUser(request, reply);
    });
    fastify.put('/update-user/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.UPDATE_USER), pathVariableMiddleware.handle] }, async (request, reply) => {
        await controller.updateUser(request, reply);
    });
    fastify.patch('/update-user-status/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.UPDATE_USER), pathVariableMiddleware.handle, ValidationMiddleware(UserSchema.addUserSchema)] }, async (request, reply) => {
        await controller.updateUserStatus(request, reply);
    });
    fastify.delete('/delete-user/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.DELETE_USER), pathVariableMiddleware.handle] }, async (request, reply) => {
        await controller.deleteUser(request, reply);
    });
    done();
}

module.exports = routes;