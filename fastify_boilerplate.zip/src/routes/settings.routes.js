const constants = require("../constants/index");
const SettingSchema = require('../schemas/setting.schema');
const SettingController = require("../controllers/controller.controller");
const AuthenticationMiddleware = require("../middleware/authentication.middleware");
const PathVariableMiddleware = require("../middleware/pathVariable.middleware");

const superAdmin = constants.SUPER_ADMIN;
const viewer = constants.VIEWER;

function routes(fastify, options, done) {

    const controller = new SettingController();
    const authenticationMiddleware = new AuthenticationMiddleware();
    const pathVariableMiddleware = new PathVariableMiddleware();

    fastify.get('/settings', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_SETTINGS)] }, async (request, reply) => {
        await controller.getAllSettingList(request, reply);
    });
    fastify.get('/editable-settings', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_SETTINGS)] }, async (request, reply) => {
        await controller.getEditableSettingsList(request, reply);
    });
    fastify.get('/setting/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_SETTINGS), pathVariableMiddleware.handle] }, async (request, reply) => {
        await controller.getSettingById(request, reply);
    });
    fastify.post('/add-setting', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.CREATE_SETTING), ValidationMiddleware(SettingSchema.addSettingSchema)] }, async (request, reply) => {
        await controller.addSetting(request, reply);
    });
    fastify.put('/update-setting/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.UPDATE_SETTING), pathVariableMiddleware.handle, ValidationMiddleware(SettingSchema.updateSettingSchema)] }, async (request, reply) => {
        await controller.updateSetting(request, reply);
    });
    fastify.patch('/update-setting-value', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.UPDATE_SETTING), ValidationMiddleware(SettingSchema.updateValueSchema)] }, async (request, reply) => {
        await controller.updateSettingByKey(request, reply);
    });
    fastify.delete('/delete-setting/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.DELETE_SETTING), pathVariableMiddleware.handle] }, async (request, reply) => {
        await controller.deleteSetting(request, reply);
    });
    done();
}

module.exports = routes;