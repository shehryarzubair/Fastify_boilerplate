const AuthSchema = require("../schemas/authentication.schema");
const AuthenticationMiddleware = require("../middleware/authentication.middleware");
const AuthenticationController = require("../controllers/authentication.controller");
const PathVariableMiddleware = require("../middleware/pathVariable.middleware");
const ValidationMiddleware = require("../middleware/validation.middleware");

function routes(fastify, options, done) {
  const controller = new AuthenticationController();
  const authenticationMiddleware = new AuthenticationMiddleware();
  const pathVariableMiddleware = new PathVariableMiddleware();
  const validationMiddlewareInstance = new ValidationMiddleware();

  fastify.post(
    "/login",
    { preValidation: [validationMiddlewareInstance.handle.bind(AuthSchema.loginSchema)] },
    async (request, reply) => {
      await controller.login(request, reply);
    }
  );
  fastify.post(
    "/reset-password-request",
    {
      preValidation: [
        validationMiddlewareInstance.handle.bind(AuthSchema.resetPasswordSchema),
      ],
    },
    async (request, reply) => {
      await controller.resetPasswordRequest(request, reply);
    }
  );
  fastify.get(
    "/verify-password-request/:id",
    { preValidation: [pathVariableMiddleware.handle] },
    async (request, reply) => {
      await controller.verifyPasswordRequest(request, reply);
    }
  );
  fastify.post(
    "/reset-password/:id",
    {
      preValidation: [
        pathVariableMiddleware.handle,
        validationMiddlewareInstance.handle.bind(AuthSchema.passwordSchema),
      ],
    },
    async (request, reply) => {
      await controller.resetPassword(request, reply);
    }
  );
  fastify.post("/migrate", controller.migrate);

  // Protected route
  fastify.get(
    "/protected",
    { preValidation: [authenticationMiddleware.handle] },
    async (request, reply) => {
      const user = request.user;
      return HelperFunctions.responseWrapper(request, reply, 200, user);
    }
  );

  done();
}

module.exports = routes;
