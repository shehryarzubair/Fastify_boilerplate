const constants = require("../constants/index");
const PermissionSchema = require('../schemas/permission.schema');
const PermissionController = require("../controllers/permissions.controller");
const AuthenticationMiddleware = require("../middleware/authentication.middleware");
const PathVariableMiddleware = require("../middleware/pathVariable.middleware");

const superAdmin = constants.SUPER_ADMIN;
const viewer = constants.VIEWER;

function routes(fastify, options, done) {

    const controller = new PermissionController();
    const pathVariableMiddleware = new PathVariableMiddleware();
    const authenticationMiddleware = new AuthenticationMiddleware();

    fastify.get('/permissions', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_PERMISSIONS)] }, async (request, reply) => {
        await controller.getAllPermissionList(request, reply);
    });
    fastify.get('/permission/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_PERMISSIONS), pathVariableMiddleware.handle] }, async (request, reply) => {
        await controller.getPermissionById(request, reply);
    });
    fastify.post('/add-permission', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.CREATE_PERMISSION), ValidationMiddleware(PermissionSchema.addPermissionSchema)] }, async (request, reply) => {
        await controller.addPermission(request, reply);
    });
    fastify.post('/add-permissions', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.CREATE_PERMISSION), ValidationMiddleware(PermissionSchema.addPermissionsSchema)] }, async (request, reply) => {
        await controller.addPermissions(request, reply);
    });
    fastify.put('/update-permission/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.UPDATE_PERMISSION), pathVariableMiddleware.handle, ValidationMiddleware(PermissionSchema.updatePermissionSchema)] }, async (request, reply) => {
        await controller.updatePermission(request, reply);
    });
    fastify.patch('/update-permission-status/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.UPDATE_PERMISSION), pathVariableMiddleware.handle, ValidationMiddleware(PermissionSchema.updatePermissionStatusSchema)] }, async (request, reply) => {
        await controller.updatePermissionStatus(request, reply);
    });
    fastify.delete('/delete-permission/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.DELETE_PERMISSION), pathVariableMiddleware.handle] }, async (request, reply) => {
        await controller.deletePermission(request, reply);
    });
    done();
}

module.exports = routes;