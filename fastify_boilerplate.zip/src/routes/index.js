
const authentication_routes = require('./authentication.routes');

function routes(fastify, options, done) {
    fastify.register(authentication_routes);
    done();
}

module.exports = routes;
