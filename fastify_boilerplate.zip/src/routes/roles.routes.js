const constants = require("../constants/index");
const RoleSchema = require('../schemas/role.schema');
const RoleController = require("../controllers/role.controller");
const AuthenticationMiddleware = require("../middleware/authentication.middleware");
const PathVariableMiddleware = require("../middleware/pathVariable.middleware");

const superAdmin = constants.SUPER_ADMIN;
const viewer = constants.VIEWER;

function routes(fastify, options, done) {

    const controller = new RoleController();
    const authenticationMiddleware = new AuthenticationMiddleware();
    const pathVariableMiddleware = new PathVariableMiddleware();

    fastify.get('/roles', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_ROLES)] }, async (request, reply) => {
        await controller.getAllRoleList(request, reply);
    });
    fastify.get('/roles-with-user', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_ROLES)] }, async (request, reply) => {
        await controller.getAllRolesWithUsersList(request, reply);
    });
    fastify.get('/role/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(viewer.READ_ROLES), pathVariableMiddleware.handle] }, async (request, reply) => {
        await controller.getRoleById(request, reply);
    });
    fastify.post('/add-role', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.CREATE_ROLE), ValidationMiddleware(RoleSchema.addRoleSchema)] }, async (request, reply) => {
        await controller.addRole(request, reply);
    });
    fastify.put('/update-role/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.UPDATE_ROLE), pathVariableMiddleware.handle, ValidationMiddleware(RoleSchema.updateRoleSchema)] }, async (request, reply) => {
        await controller.updateRole(request, reply);
    });
    fastify.put('/assign-permissions-role/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.UPDATE_ROLE), pathVariableMiddleware.handle, ValidationMiddleware(RoleSchema.assignPermissionsSchema)] }, async (request, reply) => {
        await controller.assignPermissions(request, reply);
    });
    fastify.patch('/update-role-status/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.UPDATE_ROLE), pathVariableMiddleware.handle, ValidationMiddleware(RoleSchema.updateRoleStatusSchema)] }, async (request, reply) => {
        await controller.updateRoleStatus(request, reply);
    });
    fastify.delete('/delete-role/:id', { preValidation: [authenticationMiddleware.handle, PermissionMiddleware(superAdmin.DELETE_ROLE), pathVariableMiddleware.handle] }, async (request, reply) => {
        await controller.deleteRole(request, reply);
    });
    done();
}

module.exports = routes;