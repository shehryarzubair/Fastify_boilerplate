const {
  permissionsData,
  ADMIN,
  rolePermissionData,
  statusData,
  settingsData,
} = require("../constants");
const HelperFunctions = require("../helper");
const { models } = require("../models/index");
const bcrypt = require("bcrypt");
const BaseController = require("./base.controller");

class AuthenticationController extends BaseController {
  async login(request, reply) {
    try {
      const { email, password } = request.body;
      const user = await Users.findOne({
        where: { email },
        include: [models.Roles],
      });
      if (user !== null) {
        if (!user.is_active || !user.Roles.is_active) {
          return this.responseWrapper(
            request,
            reply,
            400,
            "Please contact your administrator"
          );
        }
        const isPasswordValid = await bcrypt.compare(
          password.toString(),
          user.password.toString()
        );
        const failedLoginAttempts = await models.FailedLoginAttempt.findAll({
          where: { user_id: user.id },
          order: [["createdAt", "DESC"]],
        });
        // console.log(failedLoginAttempts.length);
        // if (failedLoginAttempts && failedLoginAttempts.length > 3) {
        //   return this.responseWrapper(
        //     request,
        //     reply,
        //     400,
        //     "Too many failed login attempts. Please try again later."
        //   );
        // }
        if (failedLoginAttempts && failedLoginAttempts.length >= 3) {
          const latestFailedAttemptTimestamp = failedLoginAttempts[0].createdAt;

          const currentTimestamp = new Date();
          const fiveMinutesAgo = new Date(
            currentTimestamp.getTime() - 5 * 60 * 1000
          );

          if (latestFailedAttemptTimestamp > fiveMinutesAgo) {
            return this.responseWrapper(
              request,
              reply,
              400,
              "Too many failed login attempts. Please try again later."
            );
          }
        }

        if (isPasswordValid) {
          await models.FailedLoginAttempt.destroy({
            where: { user_id: user.id },
          });
          // Authenticate user
          const token = fastify.jwt.sign({ user });
          user.setDataValue("token", token);
          user.setDataValue("password", null);
          user.setDataValue("message", "Logged in successfully!");
          return this.responseWrapper(request, reply, 200, user);
        } else {
          const ipdetails = getIP.get_ip;
          const clientIp = ipdetails(request).clientIp;
          await models.FailedLoginAttempt.create({
            user_id: user.id,
            ip_address: clientIp,
          });
          return this.responseWrapper(
            request,
            reply,
            400,
            "Invalid email or password"
          );
        }
      } else {
        return this.responseWrapper(
          request,
          reply,
          400,
          "Invalid email or password"
        );
      }
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async resetPasswordRequest(request, reply) {
    try {
      const { email } = request.body;
      const user = await models.Users.findOne({ where: { email } });
      if (user !== null) {
        await models.ResetPasswordRequests.destroy({
          where: { user_id: user.id },
        });
        const resetPassowordRequest = await models.ResetPasswordRequests.create(
          {
            user_id: user.id,
          }
        );
        HelperFunctions.sendEmail(
          "reset_passowrd_template",
          "Reset Password Request",
          user.email,
          { name: user.name, resetLink: resetPassowordRequest.id }
        );
        return this.responseWrapper(
          request,
          reply,
          200,
          { resetLink: resetPassowordRequest.id },
          "Reset password request sent successfully"
        );
      } else {
        return this.responseWrapper(request, reply, 400, "User not found");
      }
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async verifyPasswordRequest(request, reply) {
    try {
      const { id } = request.params;

      const resetPassowordRequest = await models.ResetPasswordRequests.findOne({
        where: { uuid: id, is_active: true },
      });
      if (resetPassowordRequest !== null) {
        const today = moment();
        const expireDate = moment(resetPassowordRequest.created_at);
        const difference = today.diff(expireDate, "minutes");
        if (difference > 15) {
          return this.responseWrapper(
            request,
            reply,
            400,
            "The link has been expired."
          );
        }
        return this.responseWrapper(
          request,
          reply,
          200,
          { resetLink: resetPassowordRequest.id },
          "Reset password request sent successfully"
        );
      } else {
        return this.responseWrapper(
          request,
          reply,
          400,
          "Reset password request not found."
        );
      }
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async resetPassword(request, reply) {
    try {
      const { id } = request.params;

      const { password } = request.body;

      const resetPassowordRequest = await models.ResetPasswordRequests.findOne({
        where: { uuid: id, is_active: true },
      });
      if (resetPassowordRequest !== null) {
        const today = moment();
        const expireDate = moment(resetPassowordRequest.created_at);
        const difference = today.diff(expireDate, "minutes");
        if (difference > 15) {
          return this.responseWrapper(
            request,
            reply,
            400,
            "The link has been expired."
          );
        }
        const user = await models.Users.findOne({
          where: { id: resetPassowordRequest.user_id },
        });
        if (user !== null) {
          const hashedPassword = await bcrypt.hash(password, 10);
          await models.Users.update(
            { password: hashedPassword },
            { where: { id } }
          );
          return this.responseWrapper(
            request,
            reply,
            200,
            {},
            "Password reset successfully"
          );
        } else {
          return this.responseWrapper(request, reply, 400, "User not found");
        }
      } else {
        return this.responseWrapper(
          request,
          reply,
          400,
          "Reset password request not found."
        );
      }
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(request, reply, 400, "Invalid request data.");
    }
  }
  // create a migrate function request
  async migrate(request, reply) {
    try {
      // add models sync methods below without comment of my models folder
      await models.Settings.sync();
      await models.Roles.sync();
      await models.Permissions.sync();
      await models.RolePermissions.sync();
      await models.Status.sync();
      await models.Companies.sync();
      await models.Users.sync();
      await models.Credits.sync();
      await models.Projects.sync();
      await models.ProjectMembers.sync();
      await models.ProjectFiles.sync();
      await models.ProjectStartups.sync();
      await models.StartupScores.sync();
      await models.StartupComments.sync();
      await models.ResetPasswordRequests.sync();
      await models.FailedLoginAttempt.sync();

      console.log(permissionsData);
      console.log(ADMIN);

      await models.Permissions.bulkCreate(permissionsData);
      const adminRole = await models.Roles.create({ name: "Super Admin" });
      await models.Roles.create({ name: "Owner" });
      await models.Roles.create({ name: "Editor" });
      await models.Roles.create({ name: "Viewer" });

      await models.RolePermissions.bulkCreate(rolePermissionData);
      await models.Status.bulkCreate(statusData);
      await models.Settings.bulkCreate(settingsData);

      const plain_password = "Test@123";
      const saltRounds = 5;

      const hashedPassword = await bcrypt.hash(
        plain_password,
        parseInt(saltRounds)
      );
      const admin = await models.Users.create({
        first_name: "Osama",
        last_name: "Yousuf",
        email: "osama.weuno@gmail.com",
        password: hashedPassword,
        company_id: null,
        role_id: adminRole.id,
      });

      let email_data = {
        name: admin.first_name + " " + admin.last_name,
        email: admin.email,
        role: adminRole.name,
        password: plain_password,
      };

      HelperFunctions.sendEmail(
        "welcome_template",
        "Password for Client Panel",
        admin.email.toString(),
        email_data,
      );
      return this.responseWrapper(
        request,
        reply,
        200,
        {},
        `DB created, permissions added successfully.`
      );
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(
        request,
        reply,
        500,
        error.message
      );
    }
  }
}

module.exports = AuthenticationController;
