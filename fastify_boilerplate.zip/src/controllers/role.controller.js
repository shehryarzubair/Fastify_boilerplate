const { models } = require("../models/index");
const BaseController = require("./base.controller");

class RoleController extends BaseController {
  async getAllRoleList(request, reply) {
    try {
      const roles = await models.Roles.findAll({
        include: {
          model: models.Permissions,
          through: {
            model: models.RolePermissions,
            attributes: [],
          },
        },
      });
      return this.responseWrapper(
        request,
        reply,
        200,
        roles,
        "Roles Successfully Fetched"
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async getAllRolesWithUsersList(request, reply) {
    try {
      const roles = await models.Roles.findAll({
        include: [
          {
            model: models.User,
            attributes: [
              "id",
              "name",
              "username",
              "email",
              "profile_picture",
              "is_active",
            ],
          },
        ],
      });
      return this.responseWrapper(
        request,
        reply,
        200,
        roles,
        "Roles Successfully Fetched"
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async getRoleById(request, reply) {
    try {
      const { id } = request.params;

      const role = await models.Roles.findByPk(id);
      if (role !== null) {
        return this.responseWrapper(
          request,
          reply,
          200,
          role,
          "Role Successfully Fetched"
        );
      } else {
        return this.responseWrapper(request, reply, 400, "No record found");
      }
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async addRole(request, reply) {
    try {
      const { name } = request.body;

      try {
        const roleAlreadyExists = await models.Roles.findOne({
          where: { name },
        });
        if (roleAlreadyExists) {
          return this.responseWrapper(
            request,
            reply,
            400,
            "Role Already Exists"
          );
        }

        const role = await models.Roles.create({ name });
        return this.responseWrapper(
          request,
          reply,
          200,
          role,
          "Role Successfully Added"
        );
      } catch (error) {
        console.log(error);
        return this.responseWrapper(
          request,
          reply,
          500,
          "Something went wrong"
        );
      }
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async updateRole(request, reply) {
    try {
      const { id } = request.params;

      const role = await models.Roles.findByPk(id);

      if (!role) {
        return this.responseWrapper(request, reply, 400, "No record found");
      }

      const formData = request.body;
      await models.Roles.update({ ...formData }, { where: { id } });
      return this.responseWrapper(
        request,
        reply,
        200,
        { ...role.dataValues, ...formData },
        "Role Successfully Updated"
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async assignPermissions(request, reply) {
    try {
      const { id } = request.params;

      const { permissions } = request.body;

      const role = await models.Roles.findByPk(id);
      if (role !== null) {
        await models.RolePermissions.destroy({ where: { role_id: id } });
        const bulkPermissions = [];
        for (let index = 0; index < permissions.length; index++) {
          const permission = permissions[index];
          const validPermission = await models.Permissions.findOne({
            where: { slug: permission },
          });
          if (!validPermission) {
            continue;
          }
          bulkPermissions.push({
            role_id: id,
            permission_id: validPermission.id,
          });
        }
        await models.RolePermissions.bulkCreate(bulkPermissions);
        return this.responseWrapper(
          request,
          reply,
          200,
          bulkPermissions,
          "Permissions Assigned Successfully"
        );
      } else {
        return this.responseWrapper(request, reply, 400, "No record found");
      }
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async updateRoleStatus(request, reply) {
    try {
      const { id } = request.params;

      const { is_active } = request.body;

      const role = await models.Roles.findByPk(id);
      if (role !== null) {
        await models.Roles.update({ is_active }, { where: { id } });
        return this.responseWrapper(
          request,
          reply,
          200,
          { ...role.dataValues, is_active },
          `Role Status Successfully Updated`
        );
      } else {
        return this.responseWrapper(request, reply, 400, "No record found");
      }
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async deleteRole(request, reply) {
    const { id } = request.params;
    const role = await models.Roles.findByPk(id);
    if (role !== null) {
      await models.Roles.destroy({ where: { id } });
      return this.responseWrapper(
        request,
        reply,
        200,
        {},
        "Record Deleted Successfully"
      );
    } else {
      return this.responseWrapper(request, reply, 400, "No record found");
    }
  }
}
module.exports = RoleController;
