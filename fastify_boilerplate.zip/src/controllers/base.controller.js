const HelperFunctions = require("../helper");

class BaseController {
    constructor() {
        this.helper = new HelperFunctions();
    }

    responseWrapper(request, reply, status, data, message) {
        return this.helper.responseWrapper(request, reply, status, data, message);
    }

    async uploadFile(requestObject, fieldNameInRequest, directoryToSaveFile) {
        return await this.helper.uploadFile(requestObject, fieldNameInRequest, directoryToSaveFile);
    }

}
module.exports = BaseController