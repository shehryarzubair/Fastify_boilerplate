const bcrypt = require("bcrypt");
const { default: slugify } = require("slugify");
const HelperFunctions = require("../helper");
const { models } = require("../models");

class UserController {
  async getAllUserList(request, reply) {
    try {
      const users = await models.Users.findAll({
        include: models.Roles,
        attributes: { exclude: ["password"] },
      });
      return this.responseWrapper(
        request,
        reply,
        200,
        users,
        "Users Successfully Fetched"
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async getUserById(request, reply) {
    try {
      const { id } = request.params;
      const valid = validatePathVariable(id);
      if (!valid) {
        return this.responseWrapper(
          request,
          reply,
          400,
          "Invalid ID provided."
        );
      }
      const user = await models.Users.findByPk(id, {
        include: models.Roles,
        attributes: { exclude: ["password"] },
      });
      if (user !== null) {
        return this.responseWrapper(
          request,
          reply,
          200,
          user,
          "User Successfully Fetched"
        );
      } else {
        return this.responseWrapper(request, reply, 400, "No record found");
      }
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async addUser(request, reply) {
    try {
      const { name, username, email, file_path, role_id } = request.body;

      const plainPassword = HelperFunctions.generateRandomPassword();
      const saltRounds = 10;

      try {
        const userAlreadyExists = await models.Users.findOne({
          where: { email },
        });
        if (userAlreadyExists) {
          return this.responseWrapper(
            request,
            reply,
            400,
            "User with this email already exists."
          );
        }

        const usernameAlreadyExists = await models.Users.findOne({
          where: { username },
        });
        if (usernameAlreadyExists) {
          return this.responseWrapper(
            request,
            reply,
            400,
            "User with this username already exists."
          );
        }

        const hashedPassword = await bcrypt.hash(
          plainPassword,
          parseInt(saltRounds)
        );

        const user = await models.Users.create({
          name: name,
          username: slugify(username, {
            lower: false,
            strict: true,
            replacement: "_",
          }),
          email: email,
          password: hashedPassword,
          profile_picture: file_path,
          role_id: role_id,
        });

        const email_data = {
          name: name,
          email: email,
          role: user?.role_id,
          password: plainPassword,
        };
        HelperFunctions.sendEmail(
          "user_tempelate",
          "User Registration",
          email_data
        );

        return this.responseWrapper(
          request,
          reply,
          200,
          user,
          "User Added Successfully"
        );
      } catch (error) {
        console.log(error);
        return this.responseWrapper(
          request,
          reply,
          500,
          "Something went wrong"
        );
      }
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async updateUser(request, reply) {
    try {
      const { id } = request.params;
      const valid = validatePathVariable(id);
      if (!valid) {
        return this.responseWrapper(
          request,
          reply,
          400,
          "Invalid ID provided."
        );
      }
      const user = await models.Users.findByPk(id);

      if (!user) {
        return this.responseWrapper(request, reply, 400, "No record found");
      }

      const formData = request.body;
      await models.Users.update({ ...formData }, { where: { id } });
      return this.responseWrapper(
        request,
        reply,
        200,
        { ...user.dataValues, ...formData },
        "User Updated Successfully"
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async updateUserStatus(request, reply) {
    try {
      const { id } = request.params;
      const valid = validatePathVariable(id);
      if (!valid) {
        return this.responseWrapper(
          request,
          reply,
          400,
          "Invalid ID provided."
        );
      }
      const { is_active } = request.body;

      const user = await models.Users.findByPk(id);
      if (user !== null) {
        await models.Users.update({ is_active }, { where: { id } });
        return this.responseWrapper(
          request,
          reply,
          200,
          { ...user.dataValues, is_active },
          "User Status Successfully Updated"
        );
      } else {
        return this.responseWrapper(request, reply, 400, "No record found");
      }
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async deleteUser(request, reply) {
    const { id } = request.params;
    const valid = validatePathVariable(id);
    if (!valid) {
      return this.responseWrapper(request, reply, 400, "Invalid ID provided.");
    }
    const user = await models.Users.findByPk(id);
    if (user !== null) {
      await models.Users.destroy({ where: { id } });
      return this.responseWrapper(
        request,
        reply,
        200,
        {},
        "Record Deleted Successfully"
      );
    } else {
      return this.responseWrapper(request, reply, 400, "No record found");
    }
  }
}
module.exports = UserController;
