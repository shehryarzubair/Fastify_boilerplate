const { models } = require("../models/index");

class PermissionController {
  async getAllPermissionList(request, reply) {
    try {
      const permissions = await models.Permissions.findAll();
      return this.responseWrapper(
        request,
        reply,
        200,
        permissions,
        "Permissions Successfully Fetched"
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async getPermissionById(request, reply) {
    try {
      const { id } = request.params;

      const permission = await models.Permissions.findByPk(id);
      if (permission !== null) {
        return this.responseWrapper(
          request,
          reply,
          200,
          permission,
          "Permission Successfully Fetched"
        );
      } else {
        return this.responseWrapper(request, reply, 400, "No record found");
      }
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async addPermission(request, reply) {
    try {
      const { name } = request.body;

      try {
        const permissionAlreadyExists = await models.Permissions.findOne({
          where: { name },
        });
        if (permissionAlreadyExists) {
          return this.responseWrapper(
            request,
            reply,
            400,
            "Permission Already Exists"
          );
        }

        const permission = await models.Permissions.create({ name });
        return this.responseWrapper(
          request,
          reply,
          200,
          permission,
          "Permission Successfully Added"
        );
      } catch (error) {
        console.log(error);
        return this.responseWrapper(
          request,
          reply,
          500,
          "Something went wrong"
        );
      }
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async addPermissions(request, reply) {
    try {
      const { permissions } = request.body;
      console.log(permissions);

      const validPermissions = [];
      for (let index = 0; index < permissions.length; index++) {
        const permission = permissions[index];
        console.log(permission);

        try {
          const permissionAlreadyExists = await models.Permissions.findOne({
            where: { name: permission },
          });
          if (permissionAlreadyExists) {
            continue;
          }
          validPermissions.push({ name: permission });
        } catch (error) {
          console.log(error);
        }
      }
      await models.Permissions.bulkCreate(validPermissions);
      return this.responseWrapper(
        request,
        reply,
        200,
        validPermissions,
        "Permission(s) Added Successfully."
      );
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async updatePermission(request, reply) {
    try {
      const { id } = request.params;

      const permission = await models.Permissions.findByPk(id);

      if (!permission) {
        return this.responseWrapper(request, reply, 400, "No record found");
      }

      const formData = request.body;
      await models.Permissions.update({ ...formData }, { where: { id } });
      return this.responseWrapper(
        request,
        reply,
        200,
        { ...permission.dataValues, ...formData },
        "Permission Updated Successfully!"
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async updatePermissionStatus(request, reply) {
    try {
      const { id } = request.params;
      const { is_active } = request.body;

      const permission = await models.Permissions.findByPk(id);
      if (permission !== null) {
        await models.Permissions.update({ is_active }, { where: { id } });
        return this.responseWrapper(
          request,
          reply,
          200,
          { ...permission.dataValues, is_active },
          "Permission Status Successfully Updated"
        );
      } else {
        return this.responseWrapper(request, reply, 400, "No record found");
      }
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async deletePermission(request, reply) {
    const { id } = request.params;
    const permission = await models.Permissions.findByPk(id);
    if (permission !== null) {
      const permissionAssignedWithRole = await models.RolePermissions.findOne({
        where: { permission_id: id },
      });
      if (permissionAssignedWithRole) {
        return this.responseWrapper(
          request,
          reply,
          400,
          "Permission cannot be deleted as it is assigned to role."
        );
      }
      await models.Permissions.destroy({ where: { id } });
      return this.responseWrapper(
        request,
        reply,
        200,
        {},
        "Record Deleted Successfully"
      );
    } else {
      return this.responseWrapper(request, reply, 400, "No record found");
    }
  }
}
module.exports = PermissionController;
