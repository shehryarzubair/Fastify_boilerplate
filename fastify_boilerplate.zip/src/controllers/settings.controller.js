const { default: slugify } = require("slugify");
const HelperFunctions = require("../helper");

class SettingController {
  async getAllSettingList(request, reply) {
    try {
      const records = await models.Settings.findAll();
      const settings = records.map((record) => {
        return {
          id: record.id,
          key: record.key,
          value:
            record.data_type == "json"
              ? JSON.parse(record.value)
              : record.data_type == "integer"
              ? parseInt(record.value)
              : record.data_type == "boolean"
              ? record.value == "true"
                ? true
                : false
              : record.data_type == "float"
              ? parseFloat(record.value)
              : record.value,
          allow_edit: record.allow_edit,
          data_type: record.data_type,
          default_value:
            record.data_type == "json"
              ? JSON.parse(record.default_value)
              : record.data_type == "integer"
              ? parseInt(record.default_value)
              : record.data_type == "boolean"
              ? record.default_value == "true"
                ? true
                : false
              : record.data_type == "float"
              ? parseFloat(record.default_value)
              : record.default_value,
          description: record.description,
        };
      });
      return this.responseWrapper(
        request,
        reply,
        200,
        settings,
        "Settings Successfully Fetched"
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async getEditableSettingsList(request, reply) {
    try {
      const records = await models.Settings.findAll({
        where: { allow_edit: true },
      });
      const settings = records.map((record) => {
        return {
          id: record.id,
          key: record.key,
          value:
            record.data_type == "json"
              ? JSON.parse(record.value)
              : record.data_type == "integer"
              ? parseInt(record.value)
              : record.data_type == "boolean"
              ? record.value == "true"
                ? true
                : false
              : record.data_type == "float"
              ? parseFloat(record.value)
              : record.value,
          allow_edit: record.allow_edit,
          data_type: record.data_type,
          default_value:
            record.data_type == "json"
              ? JSON.parse(record.default_value)
              : record.data_type == "integer"
              ? parseInt(record.default_value)
              : record.data_type == "boolean"
              ? record.default_value == "true"
                ? true
                : false
              : record.data_type == "float"
              ? parseFloat(record.default_value)
              : record.default_value,
          description: record.description,
        };
      });
      return this.responseWrapper(
        request,
        reply,
        200,
        settings,
        "Settings Successfully Fetched"
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async getSettingById(request, reply) {
    try {
      const { id } = request.params;

      const record = await models.Settings.findByPk(id);
      const setting = {
        id: record.id,
        key: record.key,
        value:
          record.data_type == "json"
            ? JSON.parse(record.value)
            : record.data_type == "integer"
            ? parseInt(record.value)
            : record.data_type == "boolean"
            ? record.value == "true"
              ? true
              : false
            : record.data_type == "float"
            ? parseFloat(record.value)
            : record.value,
        allow_edit: record.allow_edit,
        data_type: record.data_type,
        default_value:
          record.data_type == "json"
            ? JSON.parse(record.default_value)
            : record.data_type == "integer"
            ? parseInt(record.default_value)
            : record.data_type == "boolean"
            ? record.default_value == "true"
              ? true
              : false
            : record.data_type == "float"
            ? parseFloat(record.default_value)
            : record.default_value,
        description: record.description,
      };
      if (setting !== null) {
        return this.responseWrapper(
          request,
          reply,
          200,
          setting,
          "Setting Successfully Fetched"
        );
      } else {
        return this.responseWrapper(request, reply, 400, "No record found");
      }
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async addSetting(request, reply) {
    try {
      const { key, value, allow_edit, data_type, default_value, description } =
        request.body;

      try {
        const settingAlreadyExists = await models.Settings.findOne({
          where: { key },
        });
        if (settingAlreadyExists) {
          return this.responseWrapper(
            request,
            reply,
            400,
            "Setting with this key already exists."
          );
        }

        const setting = await models.Settings.create({
          key,
          value: data_type == "json" ? JSON.stringify(value) : value,
          allow_edit,
          data_type,
          default_value: data_type == "json" ? JSON.stringify(value) : value,
          description,
        });

        return this.responseWrapper(
          request,
          reply,
          200,
          setting,
          "Setting Added Successfully."
        );
      } catch (error) {
        console.log(error);
        return this.responseWrapper(
          request,
          reply,
          500,
          "Something went wrong"
        );
      }
    } catch (error) {
      console.log("error", error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async updateSetting(request, reply) {
    try {
      const { id } = request.params;

      const setting = await models.Settings.findByPk(id);

      if (!setting) {
        return this.responseWrapper(request, reply, 400, "No record found");
      }

      const formData = request.body;

      formData.key = slugify(formData.key, {
        lower: true,
        strict: true,
        replacement: "_",
      }).toUpperCase();
      formData.description = formData.description
        ? HelperFunctions.toSentenceCase(formData.description)
        : null;
      formData.value =
        formData.data_type == "json"
          ? JSON.stringify(formData.value)
          : formData.value;
      formData.default_value =
        formData.data_type == "json"
          ? JSON.stringify(formData.default_value)
          : formData.default_value;

      await models.Settings.update({ ...formData }, { where: { id } });
      return this.responseWrapper(
        request,
        reply,
        200,
        { ...setting.dataValues, ...formData },
        "Setting Updated Successfully."
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async updateSettingByKey(request, reply) {
    try {
      const { key, value } = request.body;
      const setting = await models.Settings.findOne({ where: { key } });

      if (!setting) {
        return this.responseWrapper(request, reply, 400, "No record found");
      }

      const formData = request.body;
      formData.key = slugify(formData.key, {
        lower: true,
        strict: true,
        replacement: "_",
      }).toUpperCase();
      formData.value =
        setting.data_type == "json"
          ? JSON.stringify(formData.value)
          : formData.value;
      await models.Settings.update({ value }, { where: { key } });
      return this.responseWrapper(
        request,
        reply,
        200,
        { ...setting.dataValues, ...formData },
        "Setting Updated Successfully."
      );
    } catch (error) {
      console.error(error);
      return this.responseWrapper(request, reply, 500, "Something went wrong");
    }
  }

  async deleteSetting(request, reply) {
    const { id } = request.params;
    const setting = await models.Settings.findByPk(id);
    if (setting !== null) {
      await models.Settings.destroy({ where: { id } });
      return this.responseWrapper(
        request,
        reply,
        200,
        {},
        "Record Deleted Successfully"
      );
    } else {
      return this.responseWrapper(request, reply, 400, "No record found");
    }
  }
}
module.exports = SettingController;
