const HelperFunctions = require("../helper");

exports.TYPEERROR = "error";
exports.TYPEFAILURE = "failure";
exports.TYPESUCCESS = "success";

exports.REQUIREDFIELDSMESSAGE = "Required fields are missing";

exports.INVALIDPOSTEDVALUES = "Invalid values posted";

exports.USERNAMEMINLENGTH = "6";
exports.USERNAMEMAXLENGTH = "12";
exports.USERNAMEREGEX = /^(?=.{6,12})([a-zA-Z0-9@#_-])+$/i;
exports.USERNAMEMESSAGE =
  "Username can only be a combination of lowercase alphabets, uppercase alphabets, digits and symbols(@, #, -, _)";

exports.PASSWORDMINLENGTH = "6";
exports.PASSWORDMAXLENGTH = "50";
exports.PASSWORDREGEX =
  /^.*(?=.{6,50})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])(?=.*[\W]).*$/;
exports.PASSWORDMESSAGE =
  "Password must be a combination of lowercase alphabets, uppercase alphabets, digits and symbols";

const modules = [
  "COMPANIES",
  "CREDIT",
  "PROJECT",
  "PROJECT_FILE",
  "PROJECT_MEMBER",
  "PROJECT_STARTUP",
  "STARTUP_SCORE",
  "STARTUP_COMMENT",
  "SETTING",
  "USER",
];
const permissions = modules
  ?.map((module) => [
    {
      name: `Read ${HelperFunctions.ToTitleCase(module)}${
        module.endsWith("S") ? "" : "s"
      }`,
      slug: `READ_${module}${module.endsWith("S") ? "" : "S"}`,
    },
    {
      name: `Create ${HelperFunctions.ToTitleCase(module)}`,
      slug: `CREATE_${module}`,
    },
    {
      name: `Update ${HelperFunctions.ToTitleCase(module)}`,
      slug: `UPDATE_${module}`,
    },
    {
      name: `Delete ${HelperFunctions.ToTitleCase(module)}`,
      slug: `DELETE_${module}`,
    },
  ])
  .flat();

exports.permissionsData = permissions;

exports.ADMIN = permissions.reduce((acc, permission) => {
  acc[permission.slug] = permission.slug;
  return acc;
}, {});

exports.rolePermissionData = Array(modules.length * 4)
  .fill()
  .map((_, val) => ({ role_id: 1, permission_id: val + 1 }));

exports.statusData = [
  { name: "In Progress" },
  { name: "With Co:Cubed Analyst" },
  { name: "Ready For Collaboration" },
  { name: "Not Logged in" },
  { name: "Active" },
];

const settingsModules = [
  "COMPANIES",
  "CREDITS",
  "PROJECTS",
  "PROJECT_FILES",
  "PROJECT_MEMBERS",
  "PROJECT_STARTUPS",
  "STARTUP_SCORES",
  "STARTUP_COMMENTS",
  "SETTINGS",
  "USERS",
];
exports.settingsData = settingsModules?.map((module) => ({
  key: module,
  value: 1,
  allow_edit: 1,
  data_type: "integer",
  default_value: 1,
  description: "Show/Hide Module ",
}));
