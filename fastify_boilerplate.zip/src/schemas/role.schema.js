const yup = require('yup');
const constants = require('../constants');

const addRoleSchema = yup.object().shape({
    name: yup
        .string()
        .trim()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

const updateRoleSchema = yup.object().shape({
    name: yup
        .string()
        .trim()
        .required(),
    is_active: yup
        .boolean()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

const updateRoleStatusSchema = yup.object().shape({
    is_active: yup
        .boolean()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

const assignPermissionsSchema = yup.object().shape({
    permissions: yup
        .array()
        .of(yup
            .string()
            .trim()
            .required()
            .typeError('Must be a permission slug')
        )
        .typeError('Must be an array of strings or empty array')
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

module.exports = { addRoleSchema, updateRoleSchema, updateRoleStatusSchema, assignPermissionsSchema };