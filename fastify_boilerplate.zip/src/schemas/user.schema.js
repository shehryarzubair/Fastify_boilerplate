const yup = require('yup');
const constants = require('../constants');

const addUserSchema = yup.object().shape({
    name: yup
        .string()
        .trim()
        .required(),
    username: yup
        .string()
        .trim()
        .required(),
    email: yup
        .string()
        .trim()
        .email()
        .required(),
    file_path: yup
        .string()
        .trim()
        .required(),
    role_id: yup
        .number()
        .positive()
        .integer()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

const updateUserSchema = yup.object().shape({
    name: yup
        .string()
        .trim()
        .required(),
    username: yup
        .string()
        .trim()
        .required(),
    email: yup
        .string()
        .trim()
        .email()
        .required(),
    file_path: yup
        .string()
        .trim()
        .required(),
    role_id: yup
        .number()
        .positive()
        .integer()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

module.exports = { addUserSchema, updateUserSchema };