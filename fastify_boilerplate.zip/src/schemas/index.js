
const AuthenticationSchema = require('../schemas/authentication.schema');

exports.AuthenticationSchema = AuthenticationSchema;