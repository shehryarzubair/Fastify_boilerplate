const yup = require('yup');
const constants = require('../constants');

const addSettingSchema = yup.object().shape({
    key: yup
        .string()
        .trim()
        .required(),
    value: yup
        .string()
        .trim()
        .required(),
    allow_edit: yup
        .boolean()
        .required(),
    data_type: yup
        .string()
        .oneOf(['integer', 'string', 'boolean', 'float', 'json'])
        .required(),
    default_value: yup
        .string()
        .trim()
        .required(),
    description: yup
        .string()
        .trim()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

const updateSettingSchema = yup.object().shape({
    key: yup
        .string()
        .trim()
        .required(),
    value: yup
        .string()
        .trim()
        .required(),
    allow_edit: yup
        .boolean()
        .required(),
    data_type: yup
        .string()
        .oneOf(['integer', 'string', 'boolean', 'float', 'json'])
        .required(),
    default_value: yup
        .string()
        .trim()
        .required(),
    description: yup
        .string()
        .trim()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

const updateValueSchema = yup.object().shape({
    key: yup
        .string()
        .trim()
        .required(),
    value: yup
        .string()
        .trim()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

module.exports = { addSettingSchema, updateSettingSchema, updateValueSchema };