const yup = require('yup');
const constants = require('../constants');

const addPermissionSchema = yup.object().shape({
    name: yup
        .string()
        .trim()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

const addPermissionsSchema = yup.object().shape({
    permissions: yup
        .array()
        .of(yup
            .string()
            .trim()
            .required()
            .typeError('Must be a permission slug')
        )
        .min(1, 'Must have at least one permission')
        .typeError('Must be an array of string(s)')
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

const updatePermissionSchema = yup.object().shape({
    name: yup
        .string()
        .trim()
        .required(),
    is_active: yup
        .boolean()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

const updatePermissionStatusSchema = yup.object().shape({
    is_active: yup
        .boolean()
        .required(),
})
    .required(constants.REQUIREDFIELDSMESSAGE)
    .noUnknown(true)
    .strict();

module.exports = { addPermissionSchema, addPermissionsSchema, updatePermissionSchema, updatePermissionStatusSchema };