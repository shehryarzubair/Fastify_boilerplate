const yup = require('yup');
const constants = require('../constants');

const registerSchema = yup.object().shape({
  name: yup
    .string()
    .trim()
    .required(),
  email: yup
    .string()
    .trim()
    .email()
    .required(),
  password: yup
    .string()
    .trim()
    .required()
    .min(8),
  confirmPassword: yup
    .string()
    .trim()
    .required()
    .oneOf([yup.ref('password')], 'Passwords must match')

})
  .required(constants.REQUIREDFIELDSMESSAGE)
  .noUnknown(true)
  .strict();

const loginSchema = yup.object().shape({
  email: yup
    .string()
    .trim()
    .email()
    .required(),
  password: yup
    .string()
    .trim()
    .min(constants.PASSWORDMINLENGTH)
    .max(constants.PASSWORDMAXLENGTH)
    .matches(constants.PASSWORDREGEX, constants.PASSWORDMESSAGE)
    .required()

})
  .required(constants.REQUIREDFIELDSMESSAGE)
  .noUnknown(true)
  .strict();

const resetPasswordSchema = yup.object().shape({
  email: yup
    .string()
    .trim()
    .email()
    .required(),
})
  .required(constants.REQUIREDFIELDSMESSAGE)
  .noUnknown(true)
  .strict();

const passwordSchema = yup.object().shape({
  password: yup
    .string()
    .trim()
    .min(constants.PASSWORDMINLENGTH)
    .max(constants.PASSWORDMAXLENGTH)
    .matches(constants.PASSWORDREGEX, constants.PASSWORDMESSAGE)
    .required()
})
  .required(constants.REQUIREDFIELDSMESSAGE)
  .noUnknown(true)
  .strict();

module.exports = { loginSchema, registerSchema, resetPasswordSchema, passwordSchema };
