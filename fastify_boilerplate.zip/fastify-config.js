
// internal packages
const path = require('path');
const dotenv = require('dotenv');
const cors = require('@fastify/cors');
const helmet = require('@fastify/helmet');
const fastify_server = require('fastify');
const fastifyJWT = require('@fastify/jwt');
const fastifyMultipart = require('@fastify/multipart');

dotenv.config();

const fastify = fastify_server({ logger: process.env.APP_DEBUG });

// Register fastify-jwt plugin
fastify.register(fastifyJWT, {
    secret: process.env.JWT_SECRET
}).ready((err) => {
    if (err) {
        console.error(err);
        process.exit(1);
    }
});

fastify.register(helmet, { crossOriginResourcePolicy: false });
fastify.register(cors, { origin: "*" });

fastify.register(fastifyMultipart);

fastify.register(require('@fastify/static'), {
    root: path.join(__dirname, 'public'),
    prefix: '/public/',
});

module.exports = fastify;